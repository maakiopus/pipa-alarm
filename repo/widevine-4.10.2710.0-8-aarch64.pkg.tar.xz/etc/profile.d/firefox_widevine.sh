MOZ_GMP_PATH="$MOZ_GMP_PATH${MOZ_GMP_PATH:+:}/opt/WidevineCdm/firefox/gmp-widevinecdm/system-installed"
export MOZ_GMP_PATH
